<?php

namespace App\Http\Controllers;

use App\Model\PersonCategory;
use Illuminate\Http\Request;

class PersonCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\PersonCategory  $personCategory
     * @return \Illuminate\Http\Response
     */
    public function show(PersonCategory $personCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\PersonCategory  $personCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(PersonCategory $personCategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\PersonCategory  $personCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PersonCategory $personCategory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\PersonCategory  $personCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(PersonCategory $personCategory)
    {
        //
    }
}
