<?php

namespace App\Http\Controllers;

use App\Model\PlayDetails;
use Illuminate\Http\Request;

class PlayDetailsController extends Controller
{

}
