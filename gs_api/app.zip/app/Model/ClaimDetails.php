<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ClaimDetails extends Model
{
    //
}
